#include "stdafx.h"
#include "Point.h"

Point::Point(int x, int y):x(x),y(y)
{
}

Point::Point()
{
}

Point::~Point()
{
}
