#pragma once
class Point {
	
public:
	int x;
	int y;

	Point(int x,int y);
	Point();
	~Point();


};